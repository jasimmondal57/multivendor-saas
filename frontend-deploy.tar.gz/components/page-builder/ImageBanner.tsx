'use client';

export default function ImageBanner({ settings }: any) {
  return (
    <div className="py-12">
      <div className="text-center text-gray-500 py-8">
        Image Banner Component - Coming Soon
      </div>
    </div>
  );
}

